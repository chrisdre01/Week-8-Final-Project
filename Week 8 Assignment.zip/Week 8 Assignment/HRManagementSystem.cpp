#include <iostream>
#include <iomanip>
#include <string>
#include <fstream>
#include <sstream>

using namespace std;

class Sessions {
private:
    std::string username;
    time_t startTime;

public:
    // Constructor to initialize the session with a username and start time
    Sessions(const std::string& user) : username(user), startTime(std::time(0)) {}

    // Member function to get the username
    std::string getUsername() const {
        return username;
    }

    // Member function to get the start time of the session
    time_t getStartTime() const {
        return startTime;
    }

    // Member function to display session information
    void displaySessionInfo() const {
        std::cout << "Session Information:" << std::endl;
        std::cout << "Username: " << username << std::endl;
        std::cout << "Start Time: " << std::ctime(&startTime); // Convert time to a string for readability
    }

    // You can add more member functions as needed for your specific use case
};

int main() {
    // Example usage of the Sessions class
    Sessions userSession("JohnDoe");

    // Display session information
    userSession.displaySessionInfo();

    return 0;
}

class Manager {
private:
    std::string name;
    double salary;

public:
    // Constructor to initialize Manager with a name and salary
    Manager(const std::string& n, double s) : name(n), salary(s) {}

    // Member function to get the name of the manager
    std::string getName() const {
        return name;
    }

    // Member function to get the salary of the manager
    double getSalary() const {
        return salary;
    }

    // Member function to display manager information
    void displayInfo() const {
        std::cout << "Manager Information:" << std::endl;
        std::cout << "Name: " << name << std::endl;
        std::cout << "Salary: $" << salary << std::endl;
        
    }

    // Member function to give a salary raise
    void giveRaise(double raisePercentage) {
        // Ensure raisePercentage is a positive value
        if (raisePercentage > 0) {
            salary += salary * (raisePercentage / 100.0);
            std::cout << "Salary raised by " << raisePercentage << "%." << std::endl;
        } else {
            std::cout << "Invalid raise percentage." << std::endl;
        }
    }
};

int main1() {
    // Example usage of the Manager class
    Manager manager1("Andre Johnson", 50000.0);

    // Display manager information
    manager1.displayInfo();

    // Give a salary raise of 10%
    manager1.giveRaise(10.0);

    // Display updated information
    manager1.displayInfo();

    return 0;
}


string id1[30], name[30], address[50], dob[30], mobile_no[30], doj[30], marstatus[30], workd[30], workl[40], ctc[30], socialins[30], email[30];
int total = 0;

void enter()
{
    // Enter function 
    const int MAX_EMPLOYEES = 100;

// Define arrays to store employee data
string name[MAX_EMPLOYEES];
string address[MAX_EMPLOYEES];
string dob[MAX_EMPLOYEES];
string marstatus[MAX_EMPLOYEES];
string id[MAX_EMPLOYEES];
string doj[MAX_EMPLOYEES];
string workd[MAX_EMPLOYEES];
string workl[MAX_EMPLOYEES];
string ctc[MAX_EMPLOYEES];
string socialins[MAX_EMPLOYEES];
string mobile_no[MAX_EMPLOYEES];
string email[MAX_EMPLOYEES];

int totalEmployees = 0;

void enter()
;{
    int numEmployees;

    cout << "How many employees' data do you want to enter? ";
    cin >> numEmployees;

    if (totalEmployees + numEmployees > MAX_EMPLOYEES)
    {
        cout << "Error: Not enough space for additional employees." << endl;
        return;
    }

    for (int i = totalEmployees; i < totalEmployees + numEmployees; ++i)
    {
        cout << "\nEnter the data of Employee " << i + 1 << endl << endl;

        cout << "** PERSONAL DETAILS **" << endl << endl;
        cout << "Enter Name: ";
        cin >> name[i];

        cout << "Enter Address: ";
        cin >> address[i];

        cout << "Enter Date of Birth: ";
        cin >> dob[i];

        cout << "Is Employee Married? ";
        cin >> marstatus[i];

        cout << "** WORK DETAILS **" << endl << endl;
        cout << "Enter Id: ";
        cin >> id[i];

        cout << "Enter Date of Joining: ";
        cin >> doj[i];

        cout << "Work Department: ";
        cin >> workd[i];

        cout << "Enter Work Location: ";
        cin >> workl[i];

        cout << "Enter CTC: ";
        cin >> ctc[i];

        cout << "Enter Social Insurance Id: ";
        cin >> socialins[i];

        cout << "** CONTACT DETAILS **" << endl << endl;
        cout << "Enter Mobile NO: ";
        cin >> mobile_no[i];

        cout << "Enter Email: ";
        cin >> email[i];
    }

    totalEmployees += numEmployees;
}

int main = 0
;{
    // Call the enter function
    enter();

    // You can now access the entered data in the arrays (name, address, etc.)

}
}

bool isUsernameAvailable(const string& username) {
    ifstream userFile("users.txt");
    string existingUsername;

    while (userFile >> existingUsername) {
        if (existingUsername == username) {
            cout << "Username already exists. Please choose another one." << endl;
            userFile.close();
            return false;
        }
    }

    userFile.close();
    return true;
}

string getValidUsername() {
    string username;
    bool isValid = false;

    while (!isValid) {
        cout << "Enter username: ";
        getline(cin, username);

        if (username.length() < 1) {
            cout << "Username should have at least one character." << endl;
        } else {
            isValid = isUsernameAvailable(username);
        }
    }

    return username;
}

int main2() {
    // Example usage
    string newUser = getValidUsername();
    cout << "Selected username: " << newUser << endl;

    // You can now use 'newUser' in your application
    return 0;
}

void userNameValidation()
{
    string newName, checkName;
    int MiniPass;
    bool if_ON = true;
    bool oo = true;

    // UserName Validation
    while (oo)
    {
        cout << "Enter New UserName: ";
        getline(cin, newName);
        MiniPass = newName.length();
        
        fstream yusers;
        yusers.open("Users.txt", ios::in);

        if (if_ON && MiniPass >= 1 && yusers.is_open())
        {
            string readd;
            while (getline(yusers, readd))
            {
                stringstream OnlyUsers(readd);
                OnlyUsers >> checkName;
                if (newName == checkName)
                {
                    cout << "\n*" << newName << "* UserName already exists. Try another one\n"
                         << endl;
                    if_ON = false;
                }
            }
            yusers.close();

            if (!if_ON)
            {
                if_ON = true;
            }
            else
            {
                oo = false;
            }
        }
    }

    
}

void show()
{
    // Show function 
    void showData(const string data[], int size)
;{
    if ('size' == 0)
    {
        cout << "No data to display." << endl;
    }
    else
    {
        cout << "Displaying Data:\n";
        for (int i = 0; i < 'size'; ++i)
        {
            cout << "Element " << i + 1 << ": " <<! "data"[i] << endl;
        }
    }
}

int main = 0 
;{
    const int arraySize = 5;
    string dataArray[arraySize] = {"Item 1", "Item 2", "Item 3", "Item 4", "Item 5"};

    // Call the showData function to display the contents of dataArray
    showData(dataArray, arraySize);

}
    
}

void search()
{
    // Search function 

    if (total == 0)

    {

        cout << "No data is entered" << endl;
    }

    else
    {

        string idd;

        cout << "Enter the id of Employee you want to Search: " << endl;

        cin >> idd;

        for (int i = 0; i < total; i++)

        {

            if (idd == id1[i])

            {
                cout << "RESULT FOR EMPLOYEE ID: " << idd << endl;

                cout << "** PERSONAL DETAILS **" << endl
                     << endl;

                cout << "Full Name: " << name[i] << endl;
                cout << "Address: " << address[i] << endl;
                cout << "Date of Birth: " << dob[i] << endl;
                cout << "Maritual Status: " << marstatus[i] << endl
                     << endl;

                cout << "** WORK DETAILS **" << endl
                     << endl;

                cout << "Id: " << id1[i] << endl;
                cout << "Date of Joing: " << doj[i] << endl;
                cout << "Work Department: " << workd[i] << endl;
                cout << "Work Location: " << workl[i] << endl;
                cout << "CTC: " << ctc[i] << endl;
                cout << "Social Insurance: " << socialins[i] << endl
                     << endl;

                cout << "** CONTACT DETAILS **" << endl
                     << endl;
                cout << "Mobile NO: " << mobile_no[i] << endl;
                cout << "Email Id: " << email[i] << endl;
            }
        }
    }
}

void update()
{
    // Update function
    if (total == 0)

    {

        cout << "No data is entered" << endl;
    }

    else {

        string rollno;

        cout << "Enter the Id of Employee which you want to update" << endl;

        cin >> rollno;

        for (int i = 0; i < total; i++)

        {

            if (rollno == id1[i])

            {

            cout << "\nPrevious Data: " << endl << endl;

            cout << "Data of Employee " << i + 1 << endl;

            cout << "** PERSONAL DETAILS **" << endl;

            cout << "Full Name: " << name[i] << endl;
            cout << "Address: " << address[i] << endl;
            cout << "Date of Birth: " << dob[i] << endl;
            cout << "Maritual Status: " << marstatus[i] << endl << endl;

            cout << "** WORK DETAILS **" << endl << endl;

            cout << "Id: " << id1[i] << endl;
            cout << "Date of Joing: " << doj[i] << endl;
            cout << "Work Department: " << workd[i] << endl;
            cout << "Work Location: " << workl[i] << endl;
            cout << "CTC: " << ctc[i] << endl;
            cout << "Social Insurance: " << socialins[i] << endl << endl;

            cout << "** CONTACT DETAILS **" << endl << endl;
            cout << "Mobile NO: " << mobile_no[i] << endl;
            cout << "Email Id: " << email[i] << endl;
            cout << "\nEnter new data: " << endl << endl;
            cout << "** PERSONAL DETAILS **" << endl << endl;

            cout << "Enter Name: " << endl;

            cin >> name[i];

            cout << "Enter Address: " << endl;

            cin >> address[i];

            cout << "Enter Date of Birth: " << endl;

            cin >> dob[i];

            cout << "Is Employee Married?: " << endl;

            cin >> marstatus[i];

            cout << "** WORK DETAILS **" << endl << endl;

            cout << "Enter Id: " << endl;

            cin >> id1[i];

            cout << "Enter Date of Joing: " << endl;

            cin >> doj[i];

            cout << "Work Department: " << endl;

            cin >> workd[i];

            cout << "Enter Work Location: " << endl;

            cin >> workl[i];

            cout << "Enter CTC: " << endl;

            cin >> ctc[i];

            cout << "Enter Social Insurance Id: " << endl;

            cin >> socialins[i];

            cout << "** CONTACT DETAILS **" << endl << endl;

            cout << "Enter Mobile NO: " << endl;

            cin >> mobile_no[i];

            cout << "Enter Email: " << endl;

            cin >> email[i];
            }
        }
    }
}

void Delete()
{
    // Delete function 
    if (total == 0)
    {
        cout << "No data is entered yet" << endl;
    }

    else
    {
        int a;

        cout << "Are you Sure to Delete Data?" << endl;
        cout << "Press 1 to delete all record" << endl;

        cin >> a;

        if (a == 1)

        {

            total = 0;

            cout << "All record is deleted..!!" << endl;
        }
        else
        {
            cout << "Please Press 1 to Delete All Record" << endl;
        }
    }
}

int main3()

{

    int value, sample;

    cout << "ENTER 1: To Proceed.." << endl;
    cin >> sample;

    while (sample < 2) // always in Loop

    {
        cout << ">>>>>>>>  EMPLOYEE RECORD MANAGEMENT SYSTEM  <<<<<<<<" << endl;

        cout << "\nPRESS 1: To Enter data" << endl;

        cout << "-------------------------" << endl;

        cout << "PRESSS 2: To Show data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 3: To Search data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 4: To Update data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 5: To Delete data" << endl;
        cout << "-------------------------" << endl;

        cout << "PRESSS 6: To Quit" << endl;
        cout << "-------------------------" << endl;

        cin >> value;

        switch (value)

        {

        case 1:
            enter();
            break;

        case 2:
            show();
            break;

        case 3:
            search();
            break;

        case 4:
            update();
            break;

        case 5:
            Delete();
            break;

        case 6:
            exit(0);
            break;

        default:
            cout << "Invalid input" << endl;
            break;
        }
        
    }
        return 0;
}


void login()
{
    // Login function 
    //Login function

string UserName,Password;
string UseEnter,PassEnter;
bool On_Off = true;
bool Off = true;
int countt = 0;
int left = 3;

cout << "\n**** Login to your Account **** \n";
while(On_Off){
    //********************************************
    fstream user;
    user.open("users.txt", ios::in);
    if(countt < 3 && Off && user.is_open()){
        if(countt > 0){
        cout << "\nPassword or UserName are not correct!!" << endl;
        left--;
        cout << "You have *" << left << "* attempts left \n" << endl;
        }
        cout << "Enter UserName: ";
        getline(cin,UseEnter);
        cout << "Enter Password: ";
        getline(cin,PassEnter);
        countt++;
        string read;
        //====================================================*
        while(getline(user,read)){
            stringstream convertor(read);
            convertor >> UserName >> Password;
            if(UseEnter == UserName && PassEnter == Password){
                Off = false;}}
        //=====================================================*
            }
    else if(!Off){
        cout << "\n**** Welcome! ****\n\n";
        user.close();
        On_Off = false;
}
    else {
        cout << "\n**** try again later!! **** \n\n";
        user.close();
        On_Off = false;
    }
}
}

void registry()
{

    // Your registry function code here...
    // Registry function
    string newName,checkName,newPass,confirmPass;
    int MiniPass ;
    bool if_ON = true;
    bool oo = true;

cout << "\n**** Create New Account **** \n";
}

int main4()
{
    int value, sample;

    cout << "ENTER 1: To Proceed.." << endl;
    cin >> sample;

    while (sample < 2) // always in Loop
    {
        cout << ">>>>>>>>  EMPLOYEE RECORD MANAGEMENT SYSTEM  <<<<<<<<" << endl;

        cout << "\nPRESS 1: To Enter data" << endl;
        // ... rest of your main function code ...

        cin >> value;

        switch (value)
        {
        case 1:
            enter();
            break;
        case 2:
            show();
            break;
        case 3:
            search();
            break;
        case 4:
            update();
            break;
        case 5:
            Delete();
            break;
        case 6:
            exit(0);
            break;
        default:
            cout << "Invalid input" << endl;
            break;
        }
    }

    return 0;
}
